// framer-motion types removed; the project no longer depends on framer-motion
