// Utilidad para mostrar fracciones amigables
function toFraction(value: string | number | null | undefined): string {
  if (value == null || value === '') return '';
  const num = typeof value === 'string' ? parseFloat(value) : value;
  if (isNaN(num)) return String(value);
  if (Number.isInteger(num)) return String(num);
  const denominators = [2, 3, 4, 8, 16];
  for (const d of denominators) {
    const n = Math.round(num * d);
    if (Math.abs(num - n / d) < 1e-6) {
      const whole = Math.floor(num);
      const remainder = n - whole * d;
      if (whole > 0 && remainder > 0) {
        return `${whole} ${remainder}/${d}`;
      } else if (whole > 0 && remainder === 0) {
        return `${whole}`;
      } else {
        return `${n}/${d}`;
      }
    }
  }
  return num.toFixed(2);
}
import { PDFDocument, rgb, StandardFonts, PDFName } from 'pdf-lib';
import fs from 'fs';
import path from 'path';
import { supabase } from '@/lib/supabase';

// Disable the ESLint rule for 'any' usage in this file
/* eslint-disable @typescript-eslint/no-explicit-any */

export async function generateQuotePDF({
  quote_number,
  correlative,
  contact,
  items,
  createdAt,
}:{
  quote_number?: string;
  correlative?: string;
  contact: {
    company: string;
    email: string;
    phone: string;
    document?: string | null;
    company_address: string;
    contact_name: string;
  };
  items: Array<{
    name: string;
    qty: number;
    unit_size?: string | null;
    measurement_unit?: string | null;
    price?: number | null;
    characteristics?: string[];
    description?: string;
    manufacturer?: string;
    sku?: string; // Added SKU field
  }>;
  createdAt: string;
}) {
  // Ensure we have a 4-digit correlative to show in the PDF.
  // Rule: if a valid 4-digit `correlative` parameter is provided, use it.
  // Otherwise compute the next correlative by scanning existing `quote_number`
  // values in the database. This keeps the DB schema untouched and ensures
  // the PDF always shows a sequential 0001-style identifier.
  const isValidCorrelative = (s?: string) => typeof s === 'string' && /^\d{4}$/.test(s);
  if (!isValidCorrelative(correlative)) {
    try {
      const { data: quotes } = await supabase
        .from('fasercon_quotes')
        .select('quote_number');
      let maxNum = 0;
      if (Array.isArray(quotes)) {
        for (const r of quotes) {
          const val = r?.quote_number;
          if (!val) continue;
          const str = String(val).trim();
          // Prefer a 4-digit group at the end of the string, otherwise any 4-digit group
          let m = str.match(/(\d{4})$/);
          if (!m) m = str.match(/(\d{4})/);
          if (m) {
            const n = parseInt(m[1], 10);
            if (!isNaN(n) && n > maxNum) maxNum = n;
          }
        }
      }
      correlative = String(maxNum + 1).padStart(4, '0');
    } catch (err) {
      console.warn('Could not compute correlative in PDF generator, defaulting to 0001', err);
      correlative = '0001';
    }
  }
  const pdfDoc = await PDFDocument.create();
  const page = pdfDoc.addPage([595, 842]); // A4 portrait
  const { width, height } = page.getSize();

  // Margen reducido
  const sideMargin = 24; // antes 40

  // Fuentes: intentar usar Sintony desde public/assets/fonts si existe, si no fallback a Helvetica
  let fontBold: any;
  let fontRegular: any;
  try {
    const sintonyRegularPath = path.join(process.cwd(), 'public/assets/fonts/Sintony-Regular.ttf');
    const sintonyBoldPath = path.join(process.cwd(), 'public/assets/fonts/Sintony-Bold.ttf');
    if (fs.existsSync(sintonyRegularPath) && fs.existsSync(sintonyBoldPath)) {
      const regularBytes = fs.readFileSync(sintonyRegularPath);
      const boldBytes = fs.readFileSync(sintonyBoldPath);
      fontRegular = await pdfDoc.embedFont(regularBytes);
      fontBold = await pdfDoc.embedFont(boldBytes);
    } else {
      // Fallback a fuentes estándar
      fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
      fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
    }
  } catch (err) {
    console.error('Error embedding custom fonts, falling back to StandardFonts:', err);
    fontBold = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    fontRegular = await pdfDoc.embedFont(StandardFonts.Helvetica);
  }
  
  // Paleta corporativa: rojo (primario), negro y grises
  const primaryRed = rgb(0.71, 0.11, 0.11); // aproximadamente #B71C1C
  const darkGray = rgb(0.18, 0.18, 0.18);
  const lightGray = rgb(0.95, 0.95, 0.95);

  // ============= HEADER (gris claro) =============
  // Header aún más pequeño: solo contiene el logo
  const headerHeight = 90 // más alto para mostrar el logo más grande
  page.drawRectangle({
    x: 0,
    y: height - headerHeight,
    width: width,
    height: headerHeight,
    color: lightGray,
  });

  // Logo en el header (centrado verticalmente en el header)
  try {
    const logoPath = path.join(process.cwd(), 'public/assets/images/fasercon_logo2.png');
    const logoBytes = fs.readFileSync(logoPath);
    const logoImage = await pdfDoc.embedPng(logoBytes);
    // Preservar aspect ratio: calcular tamaño que encaje en el maxWidth/maxHeight
    const maxLogoWidth = 120 * 1.5; // 30% más grande
    const maxLogoHeight = 36 * 1.5; // 30% más grande
    const imgWidth = logoImage.width;
    const imgHeight = logoImage.height;
    const scale = Math.min(maxLogoWidth / imgWidth, maxLogoHeight / imgHeight);
    const drawWidth = imgWidth * scale;
    const drawHeight = imgHeight * scale;
    const logoY = height - headerHeight + (headerHeight - drawHeight) / 2;
    page.drawImage(logoImage, {
      x: sideMargin,
      y: logoY,
      width: drawWidth,
      height: drawHeight,
    });

    // Fondo rojo a la derecha del logo
    // Texto completo y ajuste automático para que siempre se vea
    const infoText = 'Web: fasercon.cl   -   Email: ventas@ingenit.cl   -   Tel.: +56 9 9868 0862';
    let fontSize = 10;
    const infoX = sideMargin + drawWidth + 18;
    const infoY = height - headerHeight + 21; // subido 16px respecto a antes
    const infoHeight = fontSize + 10;
    const infoWidth = width - infoX - sideMargin;
    const textFont = await pdfDoc.embedFont(StandardFonts.HelveticaBold);
    let textWidth = textFont.widthOfTextAtSize(infoText, fontSize);
    // Si el texto no cabe, reducir el fontSize hasta que quepa
    while (textWidth > infoWidth - 16 && fontSize > 9) {
      fontSize -= 1;
      textWidth = textFont.widthOfTextAtSize(infoText, fontSize);
    }
    page.drawRectangle({
      x: infoX,
      y: infoY,
      width: infoWidth,
      height: infoHeight,
      color: primaryRed,
    });
    const textX = infoX + Math.max(8, (infoWidth - textWidth) / 2);
    const textY = infoY + (infoHeight - fontSize) / 2;
    page.drawText(infoText, {
      x: textX,
      y: textY,
      size: fontSize,
      color: rgb(1, 1, 1),
      font: textFont,
    });
  } catch (error) {
    console.error('Error loading logo:', error);
  }

  // Título centrado fuera del header: más grande, peso normal y gris más claro
  const marginTop = 40; // aumentar espacio vertical entre el bottom del header y el título
  // Prefer correlative for the main title when available; fall back to quote_number
  const titleText = `Solicitud de Cotización Nº ${correlative ?? quote_number ?? ''}`;
  const titleSize = 20; // más grande
  const titleWidth = fontRegular.widthOfTextAtSize(titleText, titleSize);
  const titleY = height - headerHeight - marginTop;
  const lightGrayText = rgb(0.6, 0.6, 0.7); // gris más claro
  page.drawText(titleText, {
    x: (width - titleWidth) / 2,
    y: titleY,
    size: titleSize,
    font: fontRegular,
    color: lightGrayText,
  });

  // Título 'DATOS DEL CLIENTE' y 'PRODUCTOS' con el mismo estilo y color
  // Cambiar el color de los títulos 'DATOS DEL CLIENTE' y 'PRODUCTOS' a un gris similar al borde
  const sectionTitleStyle = {
    size: 11,
    font: fontBold,
    color: rgb(0.6, 0.6, 0.6), // Cambiar a gris más claro
  };

  // Título 'DATOS DEL CLIENTE' más cerca del borde
  const datosClienteTitle = 'DATOS DEL CLIENTE';
  const datosClienteY = titleY - 30; // Incrementar el espacio vertical entre el título y 'DATOS DEL CLIENTE'
  page.drawText(datosClienteTitle, {
    x: sideMargin,
    y: datosClienteY,
    ...sectionTitleStyle,
  });

  // ============= INFORMACIÓN DEL CLIENTE (bloque con borde rojo delgado y menor interlineado) =============
  let y = datosClienteY - 5; // menos espacio entre título y borde
  const blockX = sideMargin;
  const blockWidth = width - sideMargin * 2;
  const blockHeight = 70;
  const blockY = y;

  // Borde rojo delgado (sin fondo)
  page.drawRectangle({
    x: blockX,
    y: blockY - blockHeight,
    width: blockWidth,
    height: blockHeight,
    borderColor: rgb(0.6, 0.6, 0.6), // Cambiar a gris más claro
    borderWidth: 1,
    color: undefined,
  });

  const padding = 8;
  const lineHeight = 15; // Interlineado reducido
  let textY = blockY - padding - 8;
  const textColor = rgb(0.3, 0.3, 0.3); // gris oscuro
  const textSize = 10;

  // Fila 1: Empresa (ancho completo, título en negrita)
  page.drawText('Empresa:', {
    x: blockX + padding,
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  page.drawText(`${contact.company}`, {
    x: blockX + padding + fontBold.widthOfTextAtSize('Empresa:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });
  textY -= lineHeight;

  // Fila 2: Dirección (ancho completo, título en negrita)
  page.drawText('Dirección:', {
    x: blockX + padding,
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  page.drawText(`${contact.company_address || ''}`, {
    x: blockX + padding + fontBold.widthOfTextAtSize('Dirección:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });
  // Email a la derecha de la dirección
  page.drawText('Email:', {
    x: blockX + blockWidth / 2 + padding + 40, // mover más a la derecha
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  page.drawText(`${contact.email || ''}`, {
    x: blockX + blockWidth / 2 + padding + 40 + fontBold.widthOfTextAtSize('Email:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });
  textY -= lineHeight;

  // Fila 3: Columnas
  const col1X = blockX + padding;
  const col2X = blockX + blockWidth / 2 + padding + 40; // mover segunda columna a la derecha

  // Columna 1, fila 1: RUT (título en negrita)
  page.drawText('RUT:', {
    x: col1X,
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  // Depurar el valor de contact.document para verificar si llega correctamente
  console.log('Debug RUT/document:', contact.document);

  // Asegurarse de que el valor de RUT/document se renderiza correctamente
  page.drawText(`${contact.document || 'Valor no disponible'}`, {
    x: col1X + fontBold.widthOfTextAtSize('RUT:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });

  // Columna 2, fila 1: Fecha (título en negrita)
  page.drawText('Fecha:', {
    x: col2X,
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  page.drawText(`${new Date(createdAt).toLocaleDateString('es-CL')}`, {
    x: col2X + fontBold.widthOfTextAtSize('Fecha:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });
  textY -= lineHeight;

  // Columna 1, fila 2: Contacto (título en negrita)
  page.drawText('Contacto:', {
    x: col1X,
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  // Capitalizar el nombre de contacto
  const capitalize = (str: string) => str.replace(/\b\w/g, l => l.toUpperCase());
  page.drawText(`${capitalize(contact.contact_name || '')}`, {
    x: col1X + fontBold.widthOfTextAtSize('Contacto:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });

  // Columna 2, fila 2: Teléfono (título en negrita)
  page.drawText('Teléfono:', {
    x: col2X,
    y: textY,
    size: textSize,
    font: fontBold,
    color: textColor,
  });
  page.drawText(`${contact.phone}`, {
    x: col2X + fontBold.widthOfTextAtSize('Teléfono:', textSize) + 4,
    y: textY,
    size: textSize,
    font: fontRegular,
    color: textColor,
  });

  // Mover y hacia abajo después del bloque
  y = blockY - blockHeight - 18; // mt para 'PRODUCTOS' respecto a datos del cliente

  // Título 'PRODUCTOS' con el mismo estilo y color, mb ligeramente mayor respecto a la lista de productos
  const productosTitle = 'PRODUCTOS';
  page.drawText(productosTitle, {
    x: sideMargin,
    y: y,
    ...sectionTitleStyle,
  });
  y -= 6; // espacio ligeramente mayor entre 'PRODUCTOS' y encabezados de la tabla

  // Definir la posición inicial de la tabla de productos
  const productTableStartY = y; // y después de 'PRODUCTOS'

  // Dibujar encabezados de columnas para la tabla de productos
  const columnHeaderHeight = 20;
  const columnHeaderY = productTableStartY - columnHeaderHeight;
  page.drawRectangle({
    x: sideMargin,
    y: columnHeaderY,
    width: width - sideMargin * 2,
    height: columnHeaderHeight,
    color: primaryRed,
  });

  const columnHeaderStyle = {
    size: 9, // Disminuir tamaño de texto
    font: fontBold,
    color: rgb(1, 1, 1), // Texto blanco para contraste
  };

  // Ajustar encabezados de columnas para eliminar 'Nombre' y combinar con 'Características'
  const columnHeaders = ['Código', 'Características', 'Unidad', 'Cantidad'];

  // Ajustar las posiciones de las columnas para mover 'Unidad' aún más a la derecha
  const columnPositions = [
    sideMargin + 5, // Código
    sideMargin + 50, // Características
    sideMargin + 450, // Unidad (aún más a la derecha)
    sideMargin + 490, // Cantidad
  ];

  // Calcular anchos de columnas para centrar encabezados
  const columnWidths = [
    columnPositions[1] - columnPositions[0], // Código
    columnPositions[2] - columnPositions[1], // Características
    columnPositions[3] - columnPositions[2], // Unidad
    (width - sideMargin) - columnPositions[3], // Cantidad
  ];

  columnHeaders.forEach((header, index) => {
    const headerWidth = fontBold.widthOfTextAtSize(header, columnHeaderStyle.size);
    const xPos = index >= 2 
      ? columnPositions[index] + (columnWidths[index] - headerWidth) / 2 // Centrar Unidad y Cantidad
      : columnPositions[index]; // Mantener Código y Características alineados a la izquierda
    
    page.drawText(header, {
      x: xPos,
      y: columnHeaderY + 6,
      ...columnHeaderStyle,
    });
  });

  // Definir productY antes de usarlo
  let productY = productTableStartY - columnHeaderHeight; // Definir productY antes de usarlo

  // Ampliar el alto de las filas para mostrar dos líneas: Nombre arriba y Características abajo
  const baseRowHeight = 28; // Ampliado para dos líneas

  // Mostrar nombre arriba y descripción abajo en la columna Características, alineados y con posiciones verticales claras
  items.forEach((item, idx) => {
    const name = item.name || '';
    const characteristics = (item.characteristics || []).join(', ');
    const truncatedName = name.length > 60 ? `${name.substring(0, 57)}...` : name;
    const truncatedChar = characteristics.length > 80 ? `${characteristics.substring(0, 77)}...` : characteristics;

    // Dibujar el fondo del bloque de producto
    const backgroundColor = idx % 2 === 0
      ? rgb(1, 1, 1)
      : lightGray;
    page.drawRectangle({
      x: sideMargin,
      y: productY - baseRowHeight,
      width: width - sideMargin * 2,
      height: baseRowHeight,
      color: backgroundColor,
    });

    // Nombre arriba
    page.drawText(truncatedName, {
      x: columnPositions[1],
      y: productY - 10, // más arriba
      size: 8,
      font: fontRegular,
      color: darkGray,
    });
    // Descripción abajo
    page.drawText(truncatedChar, {
      x: columnPositions[1],
      y: productY - 22, // más abajo
      size: 8,
      font: fontRegular,
      color: darkGray,
    });

    // Columna 1: Código (SKU) (mostrar aunque esté vacío)
    page.drawText(item.sku ? item.sku : '-', {
      x: columnPositions[0],
      y: productY - baseRowHeight / 2,
      size: 8,
      font: fontRegular,
      color: darkGray,
    });

    // Columna 3: Unidad (centrado)
    if (item.unit_size && item.measurement_unit) {
      const symbol = unitSymbols[item.measurement_unit] ?? item.measurement_unit;
      const unitSizeStr = toFraction(item.unit_size);
      const unitText = `${unitSizeStr}${symbol ? ' ' + symbol : ''}`;
      const unitTextWidth = fontRegular.widthOfTextAtSize(unitText, 8);
      const unitColumnWidth = columnPositions[3] - columnPositions[2];
      page.drawText(unitText, {
        x: columnPositions[2] + (unitColumnWidth - unitTextWidth) / 2,
        y: productY - baseRowHeight / 2,
        size: 8,
        font: fontRegular,
        color: darkGray,
      });
    }

    // Columna 4: Cantidad (centrado)
    const qtyText = `${item.qty}`;
    const qtyTextWidth = fontRegular.widthOfTextAtSize(qtyText, 8);
    const qtyColumnWidth = (width - sideMargin) - columnPositions[3];
    page.drawText(qtyText, {
      x: columnPositions[3] + (qtyColumnWidth - qtyTextWidth) / 2,
      y: productY - baseRowHeight / 2,
      size: 8,
      font: fontRegular,
      color: darkGray,
    });

    // Actualizar posición vertical para el siguiente producto
    productY -= baseRowHeight;
  });

  // Ajustar el borde dinámico para que no haya espacio entre el último producto y el borde inferior
  const adjustedTableHeight = productTableStartY - productY;
  page.drawRectangle({
    x: sideMargin,
    y: productTableStartY - adjustedTableHeight,
    width: width - sideMargin * 2,
    height: adjustedTableHeight,
    borderColor: primaryRed,
    borderWidth: borderThickness,
    color: undefined,
  });

  // Asegurar que los títulos sean visibles dibujándolos después del borde
  // Título 'PRODUCTOS'
  page.drawText(productosTitle, {
    x: sideMargin,
    y: productTableStartY + 6, // Ajustar para que no se superponga con el borde
    ...sectionTitleStyle,
  });

  // ============= FOOTER =============
  // Reduce the height of the footer and decrease the text size
  page.drawRectangle({
    x: 0,
    y: 0,
    width: width,
    height: 30, // Reduced from 50 to 40
    color: primaryRed,
  });
  
  const footerText = 'Web: fasercon.cl   -   Tel: +56 9 9868 0862   -   Email: ventas@fasercon.cl';
  const footerTextSize = 9; // Incrementar tamaño de texto
  const footerTextWidth = fontRegular.widthOfTextAtSize(footerText, footerTextSize);
  page.drawText(footerText, {
    x: (width - footerTextWidth) / 2, // Centrar horizontalmente
    y: 15, // Ajustar para que encaje dentro del footer
    size: footerTextSize, // Usar tamaño más grande
    font: fontRegular,
    color: rgb(1, 1, 1),
  });

  // Add a clickable link to 'fasercon.cl' in the footer
  const footerLinkText = 'Web: fasercon.cl';
  const footerLinkWidth = fontRegular.widthOfTextAtSize(footerLinkText, 8);
  const linkX = (width - footerTextWidth) / 2 + footerText.indexOf('fasercon.cl') * 4.5; // Approximate position of 'fasercon.cl'
  const linkY = 15;
  const linkRect = [
    linkX - 2, // Add padding around the text
    linkY - 2,
    linkX + footerLinkWidth + 2,
    linkY + 8,
  ];
  const linkAction = pdfDoc.context.obj({
    Type: PDFName.of('Action'),
    S: PDFName.of('URI'),
    URI: 'https://fasercon.cl',
  });
  const linkAnnot = pdfDoc.context.obj({
    Type: PDFName.of('Annot'),
    Subtype: PDFName.of('Link'),
    Rect: pdfDoc.context.obj(linkRect),
    Border: pdfDoc.context.obj([0, 0, 0]),
    A: linkAction,
  });
  const linkRef = pdfDoc.context.register(linkAnnot);
  (page.node as any).normalize();
  const annotsKey = PDFName.of('Annots');
  let annots = page.node.lookup(annotsKey);
  if (!annots) {
    annots = pdfDoc.context.obj([]);
    page.node.set(annotsKey, annots);
  }
  // Fix the annotation addition logic for the footer link
  if (Array.isArray(annots)) {
    annots.push(linkRef);
  } else if (typeof annots === 'object' && 'push' in annots) {
    (annots as any).push(linkRef);
  } else {
    console.error('Could not add annotation to the page: Annots is not an array.');
  }

  // ============= DISCLAIMER =============
  const disclaimerText = 'Esta solicitud de cotización no constituye una oferta ni compromiso comercial. Su propósito es recopilar información preliminar para evaluar alternativas. Los valores, condiciones y disponibilidad serán confirmados únicamente en una cotización formal.';
  const disclaimerTextSize = 10; // Mantener tamaño del texto
  const disclaimerHeight = 82;
  const disclaimerY = 40; // Posicionar encima del footer

  // Dibujar el borde gris
  page.drawRectangle({
    x: sideMargin,
    y: disclaimerY,
    width: width - sideMargin * 2,
    height: disclaimerHeight,
    borderColor: rgb(0.6, 0.6, 0.6),
    borderWidth: 1,
    color: undefined,
  });

  // Dibujar el texto dentro del borde con ajuste para evitar desbordamiento
  const disclaimerPadding = 20; // Añadir padding
  const disclaimerTextX = sideMargin + disclaimerPadding; // Margen interno izquierdo con padding
  const disclaimerTextY = disclaimerY + disclaimerHeight - disclaimerPadding; // Ajustar para que el texto no desborde hacia abajo
  page.drawText(disclaimerText, {
    x: disclaimerTextX,
    y: disclaimerTextY - disclaimerTextSize, // Ajustar posición vertical del texto
    size: disclaimerTextSize,
    font: fontRegular,
    color: rgb(0.6, 0.6, 0.6), // Mantener color del texto al del borde
    lineHeight: 15, // Mantener interlineado
    maxWidth: width - sideMargin * 2 - disclaimerPadding * 2, // Ajustar ancho máximo para que el texto no salga del borde
  });

  const pdfBytes = await pdfDoc.save();
  return pdfBytes;
}

// Definir unitSymbols antes de su uso
const unitSymbols: Record<string, string> = {
  in: '"',
  ft: "'",
  m: 'm',
  cm: 'cm',
  mm: 'mm',
  kg: 'kg',
  g: 'g',
  ton: 't',
  l: 'l',
  unit: '',
  box: ' caja',
  pack: ' paquete',
  roll: ' rollo',
  other: '',
};

// Definir borderThickness antes de su uso
const borderThickness = 1;

// Eliminadas variables no usadas para limpiar advertencias ESLint
