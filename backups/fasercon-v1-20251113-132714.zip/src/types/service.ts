export interface Service {
  id: string;
  title: string;
  description: string;
  images: string[];
  created_at: string;
}
